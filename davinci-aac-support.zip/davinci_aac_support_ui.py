#!/usr/bin/env python3
"""Local dashboard server for DaVinci AAC Support.

Replaces zenity dialogs with a real web page (opened in the default
browser) for both the install flow and the standalone live-activity
monitor. Stdlib only -- no new dependency for something meant to work on
any Linux desktop, regardless of which GUI toolkit (if any) is installed.

Two entry points, both backed by this same server:
  --mode install   used by install.sh: shows install progress live, or
                    (if already installed) a status/manage view instead.
  --mode monitor   used by the standalone `davinci-aac-support-monitor`
                    command: just the live status/activity view.
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import davinci_aac_support_config as settings

BIN_DIR = os.path.expanduser("~/.local/bin")
SERVICE_DIR = os.path.expanduser("~/.config/systemd/user")
DAEMON_PATH = os.path.join(BIN_DIR, "davinci_aac_support_watch.py")
UI_PATH = os.path.join(BIN_DIR, "davinci_aac_support_ui.py")
MONITOR_PATH = os.path.join(BIN_DIR, "davinci-aac-support-monitor")
SERVICE_NAME = "davinci-aac-support.service"
SERVICE_PATH = os.path.join(SERVICE_DIR, SERVICE_NAME)
STATE_DIR = os.path.expanduser("~/.cache/davinci-aac-support")
STATUS_FILE = os.path.join(STATE_DIR, "status.json")
INSTALL_LOG = os.path.join(STATE_DIR, "install-log.jsonl")
EVENTS_FILE = os.path.join(STATE_DIR, "events.jsonl")
PORT_FILE = os.path.join(STATE_DIR, "ui-port.txt")
PID_FILE = os.path.join(STATE_DIR, "ui-pid.txt")

# Idle timeout: self-destruct after this long with zero HTTP requests.
# Not wall-clock-since-start -- a real open tab (install or monitor mode
# both poll /api/status every 4s from the page's own JS) keeps this reset
# indefinitely, so a legitimate long session is never killed. This exists
# because a previous wall-clock-only version left monitor-mode servers
# (no timeout at all) running for two weeks after their tab was closed,
# found via `ps` during a manual install test.
IDLE_TIMEOUT_SECONDS = 2 * 60 * 60
_last_activity = time.time()

# How long the uninstall action waits before exiting, so the HTTP response
# confirming success has time to actually reach the browser first. A named
# constant (not an inline literal) so tests can shrink it instead of
# either sleeping for real or patching the global time.sleep.
UNINSTALL_EXIT_DELAY_SECONDS = 3


def is_installed():
    return os.path.isfile(SERVICE_PATH)


def is_process_alive(pid):
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def kill_existing_server():
    """Kills a previous instance of this server if one is still running
    (stale PID file from an install that was never cleanly stopped) --
    otherwise repeated installs/uninstalls just pile up orphaned
    processes, one per run, forever."""
    if not os.path.isfile(PID_FILE):
        return
    try:
        with open(PID_FILE) as f:
            old_pid = int(f.read().strip())
    except (OSError, ValueError):
        return
    if old_pid != os.getpid() and is_process_alive(old_pid):
        try:
            os.kill(old_pid, 15)
        except OSError:
            pass


def is_active():
    try:
        r = subprocess.run(
            ["systemctl", "--user", "is-active", "--quiet", SERVICE_NAME],
            timeout=5,
        )
        return r.returncode == 0
    except Exception:
        return False


def read_json_file(path):
    if not os.path.isfile(path):
        return None
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return None


def tail_lines(path, from_start=True):
    """Yields new lines appended to path, forever. Starts from the
    beginning if from_start, otherwise from wherever the file currently
    ends (for a monitor attaching mid-stream)."""
    while not os.path.exists(path):
        time.sleep(0.2)
    with open(path) as f:
        if not from_start:
            f.seek(0, os.SEEK_END)
        while True:
            line = f.readline()
            if line:
                yield line.rstrip("\n")
            else:
                time.sleep(0.3)


# ---------------------------------------------------------------- HTML --

PAGE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DaVinci AAC Support</title>
<style>
  :root {
    --bg: #0b0d12; --card: #161a24; --border: #262b38; --text: #e7e9ee;
    --muted: #9aa3b5; --accent: #5fd0a3; --accent-dim: #2f5c49;
    --danger: #e0685f; --danger-dim: #5c2f2c; --amber: #e0b95f;
    --mono: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
    --sans: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0; background: var(--bg); color: var(--text); font-family: var(--sans);
    line-height: 1.55; min-height: 100vh; display: flex; flex-direction: column;
  }
  .wrap { max-width: 720px; margin: 0 auto; padding: 40px 24px 64px; width: 100%; }
  header {
    padding: 40px 0 28px;
    background: radial-gradient(500px 220px at 20% 0%, rgba(95,208,163,0.14), transparent 60%);
    border-bottom: 1px solid var(--border);
  }
  h1 { font-size: 1.7rem; margin: 0 0 6px; letter-spacing: -0.01em; }
  .sub { color: var(--muted); margin: 0; font-size: 0.95rem; }
  .card {
    background: var(--card); border: 1px solid var(--border); border-radius: 14px;
    padding: 22px 24px; margin-top: 20px;
  }
  .row { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
  .pill {
    display: inline-flex; align-items: center; gap: 6px; font-size: 0.8rem;
    padding: 4px 10px; border-radius: 999px; font-weight: 600;
  }
  .pill.ok { background: rgba(95,208,163,0.12); color: var(--accent); border: 1px solid var(--accent-dim); }
  .pill.bad { background: rgba(224,104,95,0.12); color: var(--danger); border: 1px solid var(--danger-dim); }
  .pill.wait { background: rgba(224,185,95,0.12); color: var(--amber); border: 1px solid #5c4d2f; }
  .kv { margin-top: 14px; font-size: 0.92rem; }
  .kv div { display: flex; justify-content: space-between; padding: 5px 0; border-bottom: 1px dashed var(--border); }
  .kv div:last-child { border-bottom: none; }
  .kv span:first-child { color: var(--muted); }
  .btn {
    display: inline-flex; align-items: center; gap: 8px; padding: 10px 18px; border-radius: 9px;
    font-weight: 600; font-size: 0.9rem; border: 1px solid var(--border); background: transparent;
    color: var(--text); cursor: pointer; font-family: inherit;
  }
  .btn:hover { border-color: var(--accent-dim); }
  .btn.primary { background: var(--accent); color: #0b1712; border-color: var(--accent); }
  .btn.danger { color: var(--danger); border-color: var(--danger-dim); }
  .btn:disabled { opacity: 0.5; cursor: default; }
  .btns { display: flex; gap: 10px; margin-top: 18px; flex-wrap: wrap; }
  .log {
    font-family: var(--mono); font-size: 0.85rem; background: #0d1017; border: 1px solid var(--border);
    border-radius: 10px; padding: 14px 16px; margin-top: 20px; max-height: 340px; overflow-y: auto;
  }
  .log .line { padding: 2px 0; white-space: pre-wrap; }
  .log .step { color: var(--muted); }
  .log .ok::before { content: "✔ "; color: var(--accent); }
  .log .ok { color: var(--text); }
  .log .fail::before { content: "✘ "; }
  .log .fail { color: var(--danger); }
  .log .event { color: var(--text); }
  .log .event.detected::before { content: "● "; color: var(--amber); }
  .log .event.converting::before { content: "◐ "; color: var(--amber); }
  .log .event.fixed::before { content: "✔ "; color: var(--accent); }
  .log .event.failed::before { content: "✘ "; color: var(--danger); }
  .ask { background: rgba(224,185,95,0.08); border: 1px solid #5c4d2f; border-radius: 10px; padding: 16px; margin-top: 18px; }
  .ask p { margin: 0 0 12px; white-space: pre-wrap; }
  .hidden { display: none !important; }
  .radio-row, .checkbox-row {
    display: flex; align-items: flex-start; gap: 10px; padding: 8px 0; cursor: pointer; font-size: 0.92rem;
  }
  .radio-row input, .checkbox-row input { margin-top: 3px; accent-color: var(--accent); }
  .hint { color: var(--muted); font-size: 0.85rem; display: block; }
  input[type="text"] {
    width: 100%; background: #0d1017; border: 1px solid var(--border); border-radius: 8px;
    color: var(--text); padding: 9px 12px; font-family: inherit; font-size: 0.9rem;
  }
  input[type="text"]:focus { outline: none; border-color: var(--accent-dim); }
  .setting-info {
    font-size: 0.85rem; color: var(--muted); background: rgba(255,255,255,0.03);
    border-radius: 8px; padding: 10px 12px; margin: 14px 0 0;
  }
  #settings-saved { color: var(--accent); font-size: 0.9rem; align-self: center; }
  .spinner {
    width: 14px; height: 14px; border-radius: 50%; border: 2px solid var(--border);
    border-top-color: var(--accent); animation: spin 0.7s linear infinite; display: inline-block;
  }
  @keyframes spin { to { transform: rotate(360deg); } }
  footer { margin-top: auto; padding: 20px 0; text-align: center; color: var(--muted); font-size: 0.8rem; }
  a { color: var(--accent); }
</style>
</head>
<body>
<header><div class="wrap">
  <h1>DaVinci AAC Support</h1>
  <p class="sub" id="subtitle">Checking status&hellip;</p>
</div></header>
<div class="wrap">

  <div class="card" id="status-card">
    <div class="row">
      <strong id="status-title">&nbsp;</strong>
      <span class="pill wait" id="status-pill"><span class="spinner"></span> checking</span>
    </div>
    <div class="kv" id="status-kv"></div>
    <div class="btns" id="status-btns"></div>
  </div>

  <div class="card" id="settings-card">
    <div class="row"><strong>Settings</strong></div>
    <label class="radio-row">
      <input type="radio" name="mode" value="in_place" id="mode-in-place">
      <span>Convert in place<span class="hint">Overwrites the original file. No extra disk space used.</span></span>
    </label>
    <label class="radio-row">
      <input type="radio" name="mode" value="separate_directory" id="mode-separate">
      <span>Save fixed copies to a separate folder<span class="hint">Original file is never touched or modified.</span></span>
    </label>
    <div id="output-dir-row" class="hidden" style="margin-top:6px; margin-left:26px">
      <input type="text" id="output-dir-input" placeholder="/home/you/DaVinciAacSupportFixed">
    </div>
    <label class="checkbox-row" style="margin-top:6px">
      <input type="checkbox" id="container-change-input">
      <span>Preserve extra streams (timecode, GPS/telemetry) when possible<span class="hint">Some camera files carry a stream that can only be kept by changing the file's container format.</span></span>
    </label>
    <p class="setting-info" id="settings-info"></p>
    <div class="btns">
      <button class="btn primary" id="settings-save">Save settings</button>
      <span id="settings-saved" class="hidden">Saved</span>
    </div>
  </div>

  <div class="ask hidden" id="ask-card">
    <p id="ask-text"></p>
    <div class="btns">
      <button class="btn primary" onclick="answer(true)">Yes, proceed</button>
      <button class="btn" onclick="answer(false)">No, cancel</button>
    </div>
  </div>

  <div class="log hidden" id="log"></div>
</div>
<footer>davinci-aac-support &middot; <a href="https://github.com/broskisworld/davinci-aac-support" target="_blank">GitHub</a></footer>

<script>
const MODE = %%MODE%%;
let askId = null;

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}

function logLine(cls, text) {
  const log = document.getElementById('log');
  log.classList.remove('hidden');
  const line = el('div', 'line ' + cls, text);
  log.appendChild(line);
  log.scrollTop = log.scrollHeight;
}

function answer(yes) {
  document.getElementById('ask-card').classList.add('hidden');
  fetch('/api/answer', {method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({id: askId, answer: yes ? 'yes' : 'no'})});
}

function renderStatus(s) {
  const title = document.getElementById('status-title');
  const pill = document.getElementById('status-pill');
  const kv = document.getElementById('status-kv');
  const btns = document.getElementById('status-btns');
  kv.innerHTML = '';
  btns.innerHTML = '';

  if (!s.installed) {
    title.textContent = 'Not installed';
    pill.className = 'pill bad'; pill.innerHTML = 'not installed';
    return;
  }

  title.textContent = s.active ? 'Watcher running' : 'Watcher installed, not running';
  pill.className = 'pill ' + (s.active ? 'ok' : 'bad');
  pill.innerHTML = s.active ? 'active' : 'stopped';

  const rows = [];
  if (s.status) {
    rows.push(['Connected to Resolve', s.status.connected ? 'yes' : 'no']);
    if (s.status.product) rows.push(['Resolve', s.status.product + ' ' + (s.status.version || '')]);
    if (s.status.project) rows.push(['Project', s.status.project]);
    rows.push(['Clips fixed', s.status.fixed_count || 0]);
    if (s.status.last_fixed) rows.push(['Last fixed', s.status.last_fixed]);
  }
  for (const [k, v] of rows) {
    const row = el('div');
    row.appendChild(el('span', null, k));
    row.appendChild(el('span', null, String(v)));
    kv.appendChild(row);
  }

  if (MODE === 'monitor' || s.active) {
    const b = el('button', 'btn danger', 'Uninstall');
    b.onclick = () => { if (confirm('Remove the watcher and installed files?')) doAction('uninstall'); };
    btns.appendChild(b);
    const r = el('button', 'btn', 'Restart');
    r.onclick = () => doAction('restart');
    btns.appendChild(r);
  }
}

function doAction(action) {
  fetch('/api/action', {method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({action})}).then(r => r.json()).then(() => refreshStatus());
}

function refreshStatus() {
  fetch('/api/status').then(r => r.json()).then(s => {
    document.getElementById('subtitle').textContent =
      MODE === 'monitor' ? 'Live status' : (s.installed ? 'Already installed' : 'Installing');
    renderStatus(s);
  });
}

function streamEvents() {
  const es = new EventSource('/api/events?stream=' + MODE);
  es.onmessage = (e) => {
    const msg = JSON.parse(e.data);
    if (msg.type === 'step') logLine('step', msg.text);
    else if (msg.type === 'ok') logLine('ok', msg.text);
    else if (msg.type === 'fail') logLine('fail', msg.text);
    else if (msg.type === 'ask') {
      askId = msg.id;
      document.getElementById('ask-text').textContent = msg.text;
      document.getElementById('ask-card').classList.remove('hidden');
    } else if (msg.type === 'event') {
      logLine('event ' + msg.kind, msg.text);
      refreshStatus();
    } else if (msg.type === 'done') {
      refreshStatus();
    }
  };
}

function settingsFromForm() {
  return {
    conversion_mode: document.querySelector('input[name="mode"]:checked').value,
    output_directory: document.getElementById('output-dir-input').value,
    allow_container_change: document.getElementById('container-change-input').checked,
  };
}

function renderSettings(s) {
  document.getElementById(s.conversion_mode === 'separate_directory' ? 'mode-separate' : 'mode-in-place').checked = true;
  document.getElementById('output-dir-input').value = s.output_directory;
  document.getElementById('container-change-input').checked = !!s.allow_container_change;
  document.getElementById('output-dir-row').classList.toggle('hidden', s.conversion_mode !== 'separate_directory');

  const info = document.getElementById('settings-info');
  if (s.conversion_mode === 'separate_directory') {
    info.textContent = 'The original file is never modified in this mode -- it stays wherever it already is.';
  } else if (s.allow_container_change) {
    info.textContent = "Extra streams are kept when possible. This can change the file's container format (still opens normally everywhere).";
  } else {
    info.textContent = 'Video and audio are always kept. A file with an extra stream (timecode, GPS/telemetry -- common on drone/action-cam footage) will have that stream dropped.';
  }
}

function loadSettings() {
  fetch('/api/settings').then(r => r.json()).then(renderSettings);
}

document.querySelectorAll('input[name="mode"]').forEach(r => r.addEventListener('change', () => renderSettings(settingsFromForm())));
document.getElementById('container-change-input').addEventListener('change', () => renderSettings(settingsFromForm()));

document.getElementById('settings-save').onclick = () => {
  fetch('/api/settings', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(settingsFromForm())})
    .then(r => r.json()).then(s => {
      renderSettings(s);
      const saved = document.getElementById('settings-saved');
      saved.classList.remove('hidden');
      setTimeout(() => saved.classList.add('hidden'), 1500);
    });
};

refreshStatus();
streamEvents();
loadSettings();
setInterval(refreshStatus, 4000);
</script>
</body>
</html>
"""


# ------------------------------------------------------------- server --

class Handler(BaseHTTPRequestHandler):
    server_version = "davinci-aac-support-ui/1"

    def log_message(self, fmt, *args):
        pass  # keep stdout clean; install.sh doesn't parse this process's own logs

    def _json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        global _last_activity
        _last_activity = time.time()
        path = self.path.split("?")[0]
        if path == "/":
            body = PAGE.replace("%%MODE%%", json.dumps(self.server.mode)).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif path == "/api/status":
            installed = is_installed()
            self._json({
                "installed": installed,
                "active": is_active() if installed else False,
                "status": read_json_file(STATUS_FILE),
            })
        elif path == "/api/events":
            self._stream_events()
        elif path == "/api/settings":
            self._json(settings.load_config())
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        global _last_activity
        _last_activity = time.time()
        length = int(self.headers.get("Content-Length", 0))
        try:
            body = json.loads(self.rfile.read(length) or b"{}")
        except Exception:
            body = {}

        if self.path == "/api/answer":
            answer_id = body.get("id")
            answer = body.get("answer")
            if answer_id:
                with open(os.path.join(STATE_DIR, f"answer-{answer_id}.txt"), "w") as f:
                    f.write(answer or "no")
            self._json({"ok": True})
        elif self.path == "/api/action":
            action = body.get("action")
            result = self._do_action(action)
            self._json(result)
        elif self.path == "/api/settings":
            result = self._save_settings(body)
            self._json(result, 200 if result.get("ok") else 400)
        else:
            self.send_response(404)
            self.end_headers()

    def _save_settings(self, body):
        mode = body.get("conversion_mode")
        if mode not in (settings.MODE_IN_PLACE, settings.MODE_SEPARATE_DIRECTORY):
            return {"ok": False, "error": "invalid conversion_mode"}
        output_directory = body.get("output_directory")
        if not isinstance(output_directory, str) or not output_directory.strip():
            return {"ok": False, "error": "output_directory must be a non-empty path"}
        updated = settings.save_config({
            "conversion_mode": mode,
            "output_directory": os.path.expanduser(output_directory.strip()),
            "allow_container_change": bool(body.get("allow_container_change")),
        })
        return {"ok": True, **updated}

    def _do_action(self, action):
        if action == "restart":
            subprocess.run(["systemctl", "--user", "restart", SERVICE_NAME], timeout=15)
            return {"ok": True}
        if action == "uninstall":
            subprocess.run(["systemctl", "--user", "disable", "--now", SERVICE_NAME], timeout=15)
            for p in (SERVICE_PATH, DAEMON_PATH, UI_PATH, MONITOR_PATH):
                try:
                    os.remove(p)
                except FileNotFoundError:
                    pass
            subprocess.run(["systemctl", "--user", "daemon-reload"], timeout=15)
            # Not removing STATE_DIR outright -- this server process (and
            # the page's own ongoing status polling) lives under it, so
            # pulling the directory out from under itself while still
            # serving the confirmation is asking for trouble. Instead,
            # exit shortly after this response is sent: this is the one
            # server lifecycle event that can't rely on the idle-timeout
            # thread (uninstall clearly means "done", not "idle"), and
            # unlike install.sh's own --uninstall path, nothing external
            # is watching this process's PID to kill it for us.
            def delayed_exit():
                time.sleep(UNINSTALL_EXIT_DELAY_SECONDS)
                for p in (PID_FILE, PORT_FILE):
                    try:
                        os.remove(p)
                    except FileNotFoundError:
                        pass
                os._exit(0)
            threading.Thread(target=delayed_exit, daemon=True).start()
            return {"ok": True}
        return {"ok": False, "error": "unknown action"}

    def _stream_events(self):
        source = INSTALL_LOG if self.server.mode == "install" else EVENTS_FILE
        # Monitor mode: show recent history first (tail from start of an
        # already-populated file), then keep streaming. Install mode: the
        # log is fresh for this run, always read from the start.
        from_start = True
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.end_headers()
        try:
            for line in tail_lines(source, from_start=from_start):
                if not line.strip():
                    continue
                self.wfile.write(f"data: {line}\n\n".encode())
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            return


CHROMIUM_BROWSER_CANDIDATES = ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser")


def open_browser(url):
    time.sleep(0.3)
    # A plain browser tab -- address bar, other tabs, "you're looking
    # at a website" framing -- doesn't read as "installing an app".
    # Chromium's --app= mode opens a standalone, chrome-less window
    # instead (no address bar, no tabs, just the page with its own
    # window/taskbar entry) -- a real installer window, not a webpage.
    # subprocess.Popen (not .run): launching a browser that isn't
    # already running blocks until that window is closed, and this
    # runs on a daemon thread, so .run() would just sit there
    # harmlessly -- but Popen is the correct fire-and-forget tool for
    # the job regardless, not "harmless to block on" by accident.
    for browser in CHROMIUM_BROWSER_CANDIDATES:
        path = shutil.which(browser)
        if not path:
            continue
        try:
            subprocess.Popen(
                [path, f"--app={url}", "--window-size=560,760"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
            )
            return
        except OSError:
            continue
    # No Chromium-based browser found at all -- fall back to whatever
    # the default browser is, as a plain tab. Still functional, just
    # not as polished.
    try:
        subprocess.Popen(["xdg-open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except FileNotFoundError:
        pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["install", "monitor"], required=True)
    parser.add_argument("--port", type=int, default=0)
    args = parser.parse_args()

    os.makedirs(STATE_DIR, exist_ok=True)
    kill_existing_server()

    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    server.mode = args.mode
    port = server.server_address[1]
    with open(PORT_FILE, "w") as f:
        f.write(str(port))
    with open(PID_FILE, "w") as f:
        f.write(str(os.getpid()))

    url = f"http://127.0.0.1:{port}/"
    print(f"SERVER_URL={url}", flush=True)

    threading.Thread(target=open_browser, args=(url,), daemon=True).start()

    # Idle-timeout self-destruct, same for both modes: a real open tab
    # (either mode's page polls /api/status every 4s) keeps resetting
    # this, so a legitimate session is never killed mid-use -- this only
    # fires once nothing has looked at the page in IDLE_TIMEOUT_SECONDS,
    # e.g. the tab was closed and the process just forgotten about.
    def idle_watchdog():
        while True:
            time.sleep(60)
            if time.time() - _last_activity > IDLE_TIMEOUT_SECONDS:
                os._exit(0)
    threading.Thread(target=idle_watchdog, daemon=True).start()

    server.serve_forever()


if __name__ == "__main__":
    main()
